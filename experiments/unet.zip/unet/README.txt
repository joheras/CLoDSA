These notebooks can be run online using Google Colab from the following links:
- Experiment D1: https://colab.research.google.com/drive/18imzikmSxqeATIQ7zQuKl6SUVuui8orF
- Experiment D2: https://colab.research.google.com/drive/169fCFwGwKULb5TnR4KXwF8ZZIBQoErT8
- Experiment D3: https://colab.research.google.com/drive/1lQ7p2JrTurcexvNOtvssptkCJFjhgH0d
- Experiment D4: https://colab.research.google.com/drive/1SNnNexysDh3f9zOFGUvdHP_tZkfFO04M
